F1R3FLY LOGO FILES — "color-on-dark" vs "color-on-black-solid"
==============================================================

This download includes two versions of the logo:

  *-color-on-dark         Transparent background. Use ONLY on a genuinely
                          dark surface (black, near-black, dark photography).
                          The logo's darker areas blend into whatever sits
                          behind it.

  *-color-on-black-solid  The same logo with a SOLID BLACK background built
                          in. Use this when you can't control the surface
                          (white / light layouts, documents, slides, photos)
                          and you want the logo to always sit on its correct
                          black field.

  ! Do not place the -color-on-black-solid version on another dark or
    near-black color. The solid black panel will show a hard edge. On a
    dark surface, use the transparent -color-on-dark version instead.

Formats:  SVG (scales to any size)  -  PNG  -  PDF (print)
(c) F1R3FLY, 2026. All rights reserved.
