F1R3FLY BRAND SWATCH LIBRARIES — v3, June 10, 2026 (evening)
Mirrors Hannah's sheet: 02 Working files/f1r3fly-brand-color-system.ai
Change log: 09 AI Resources/Projects/F1R3FLY/Brand Updates.md (2026-06-10)

THE SYSTEM:
  - SAGE IS GONE. Removed entirely (Hannah, June 10 evening). Future
    assets move toward Blue or Yellow.
  - PRIMARY: Black #000000, White #FFFFFF, Brand Yellow #F3D630,
    Brand Sky #3FA9F5, + the Yellow > Sky gradient. Primary always leads.
  - SECONDARY: the 8 audience colors + 4 audience gradients. For topic /
    audience color coding only — never the lead.
  - Hue-lock rule: lighten, darken, or saturate any brand color freely
    as long as the HUE stays constant. Anchors: Yellow 51 deg / Sky 205 deg.
  - Example variants (hue-locked, exact): Light Yellow #F7E478,
    Dark Yellow #332B00, Light Sky #82C7F8, Dark Sky #003257.
  - Dev Blue hue-snap (#007BC4 > #0072C4) is PROPOSED, not applied.
    Pending blues consolidation.

f1r3fly-brand-swatches.ase
  16 solid swatches in 3 named groups (Primary, Secondary, Hue Variant
  Examples). RGB.
  LOAD VIA THE SWATCHES PANEL, NOT FILE > OPEN:
  Illustrator: Swatches panel menu > Open Swatch Library > Other Library...
  InDesign: Swatches panel menu > Load Swatches...
  Photoshop: Swatches panel menu > Import Swatches...
  ASE cannot store gradients — that's what the .jsx is for.

f1r3fly-brand-swatches.jsx
  Run once in Illustrator (File > Scripts > Other Script...).
  Rebuilds Hannah's color-system sheet (820x940, grid-exact) with all
  swatches in named groups + 5 gradient swatches. Save as
  f1r3fly-brand-swatches.ai and load anywhere via
  Swatches panel menu > Open Swatch Library > Other Library...

Gradients (all linear, 0 deg, two stops):
  Primary    #F3D630 > #3FA9F5   (the brand identifier — leads)
  Client     #5C0269 > #7B0429
  Developer  #007BC4 > #009188
  Partner    #0C8E23 > #7A9D0E
  Neutral    #1114AD > #3F3F3F   (inferred from palette pair; Indigo is
                                  hue 239 deg, NOT a darker Sky —
                                  keep-or-kill at blues consolidation)
