# F1R3FLY Color System — Complete Hex List
*Generated June 12, 2026 — values computed at exact hue-lock, matching `f1r3fly-color-system-sheet.jsx` (v4) and `f1r3fly-canva-palette-sheet.svg`.*
*Rule: any brand color may be lightened, darkened, or shifted in saturation — the HUE stays constant.*

## Primary

| Color | Hex |
|---|---|
| Black | `#000000` |
| White | `#FFFFFF` |
| Brand Yellow | `#F3D630` |
| Brand Sky | `#3FA9F5` |

Primary gradient: `#F3D630` → `#3FA9F5` (Yellow → Sky)

## Secondary

| Color | Hex |
|---|---|
| Client Purple | `#5C0269` |
| Client Scarlet | `#7B0429` |
| Dev Blue | `#007BC4` |
| Dev Teal | `#009188` |
| Partner Green | `#0C8E23` |
| Partner Lime | `#7A9D0E` |
| Neutral Indigo | `#1114AD` |
| Neutral Gray | `#3F3F3F` |

Secondary gradients: Client `#5C0269`→`#7B0429` · Developer `#007BC4`→`#009188` · Partner `#0C8E23`→`#7A9D0E` · Neutral `#1114AD`→`#3F3F3F`

## Hue Ramps (tints + shades, one locked hue per row)

| Hue | Darkest | Darker | Darkened | (Extra) | ORIGINAL | Light/Lighter | Lighter/Lightest | Lightest |
|---|---|---|---|---|---|---|---|---|
| Brand Yellow (51°) | `#1A1600` | `#403600` | `#A68D00` | Saturated `#F2CE00` | `#F3D630` | — | `#FFEC80` | `#FFF5BF` |
| Brand Sky (205°) | `#001626` | `#003459` | `#00528C` | Dev Blue `#007BC4`* | `#3FA9F5` | — | `#7AC2F5` | `#93CCF5` |
| Client Purple | `#220027` | `#33003A` | `#470051` | — | `#5C0269` | `#A14FAC` | `#CA94D2` | `#E9D1ED` |
| Client Scarlet | `#2B000D` | `#430015` | `#5E001D` | — | `#7B0429` | `#B65574` | `#D799AC` | `#EFD3DC` |
| Dev Teal | `#00302D` | `#004C48` | `#006E67` | — | `#009188` | `#58C3BC` | `#9BDEDA` | `#D5F2F0` |
| Partner Green | `#002F08` | `#004B0D` | `#006C13` | — | `#0C8E23` | `#60C171` | `#A0DDAB` | `#D7F1DC` |
| Partner Lime | `#263200` | `#3E5200` | `#5A7700` | — | `#7A9D0E` | `#B0C964` | `#D3E2A4` | `#EDF3D9` |
| Neutral Indigo | `#000136` | `#000259` | `#000382` | — | `#1114AD` | `#6A6CD2` | `#A8A9E6` | `#DBDBF5` |
| Neutral Gray | `#1E1E1E` | `#282828` | `#333333` | — | `#3F3F3F` | `#959595` | `#C5C5C5` | `#E8E8E8` |

\* Dev Blue rides the Sky ramp as a second original — blues consolidation still pending (snap candidate `#0072C4`).

## Curated Brand Kit set (Canva, 32 colors)

Primary (4) + Secondary (8) + this tints/shades cut (20):
`#A68D00` `#FFEC80` `#FFF5BF` `#00528C` `#7AC2F5` `#93CCF5` `#A14FAC` `#E9D1ED` `#B65574` `#EFD3DC` `#58C3BC` `#D5F2F0` `#60C171` `#D7F1DC` `#B0C964` `#EDF3D9` `#6A6CD2` `#DBDBF5` `#959595` `#E8E8E8`
