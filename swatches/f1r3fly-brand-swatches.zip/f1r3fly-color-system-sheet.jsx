// =====================================================================
// F1R3FLY Brand Color System Sheet — full builder with hue ramps
// Hannah Adams / F1R3FLY Industries — June 12, 2026 (v4)
//
// Builds the complete color-system sheet (the 06.11.2026 working file)
// in a NEW document, including the hue-variant ramps for every brand
// color — the part Hannah was placing by hand.
//
//   - All ramp values computed at runtime, hue-locked EXACTLY:
//       Yellow ramp locked to 51 deg, Sky ramp locked to 205 deg,
//       each secondary locked to its own base hue.
//     (Hannah's hand-placed Yellow/Sky chips drifted 2-7 deg off
//      anchor; this snaps them. S/B values for Yellow/Sky rows are
//      kept from her draft.)
//   - Sky row carries Dev Blue #007BC4 as a second ORIGINAL chip
//     (blues-consolidation candidate, per June 10 decision — Dev Blue
//     itself is NOT altered).
//   - Partner Green included (9 ramp rows total).
//   - Neutral Gray ramp is a pure value ladder (S=0, no hue).
//   - Section retitled "HUE VARIANTS (tints + shades)" — the old
//     "LIGHT VARIANTS" heading predates the dark steps.
//   - Every chip is also added as a named swatch in grouped sets,
//     so Naomi can load this file as a swatch library.
//
// HOW TO USE:
//   1. Illustrator > File > Scripts > Other Script... > pick this file
//   2. It builds a new 820 x 1580 document — compare against your
//      hand-built sheet, then Save As over
//      f1r3fly-brand-color-system-06.11.2026.ai (or a new date).
// =====================================================================

(function () {
  var W = 820, H = 1580;
  var doc = app.documents.add(DocumentColorSpace.RGB, W, H);

  // ---- Color helpers ---------------------------------------------------
  function rgb(r, g, b) {
    var c = new RGBColor();
    c.red = Math.round(r); c.green = Math.round(g); c.blue = Math.round(b);
    return c;
  }
  function hsbToRgbArr(h, s, b) {
    // h 0-360, s 0-100, b 0-100 -> [r,g,b] 0-255
    s /= 100; b /= 100;
    var c = b * s;
    var hp = (h % 360) / 60;
    var x = c * (1 - Math.abs(hp % 2 - 1));
    var r1 = 0, g1 = 0, b1 = 0;
    if      (hp < 1) { r1 = c; g1 = x; }
    else if (hp < 2) { r1 = x; g1 = c; }
    else if (hp < 3) { g1 = c; b1 = x; }
    else if (hp < 4) { g1 = x; b1 = c; }
    else if (hp < 5) { r1 = x; b1 = c; }
    else             { r1 = c; b1 = x; }
    var m = b - c;
    return [Math.round((r1 + m) * 255),
            Math.round((g1 + m) * 255),
            Math.round((b1 + m) * 255)];
  }
  function rgbToHsb(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b)), d = mx - mn;
    var h = 0;
    if (d !== 0) {
      if (mx === r)      h = 60 * (((g - b) / d) % 6);
      else if (mx === g) h = 60 * ((b - r) / d + 2);
      else               h = 60 * ((r - g) / d + 4);
    }
    if (h < 0) h += 360;
    return [h, mx === 0 ? 0 : (d / mx) * 100, mx * 100];
  }
  function hex2(n) { var s = Math.round(n).toString(16).toUpperCase(); return s.length < 2 ? "0" + s : s; }
  function toHex(a) { return "#" + hex2(a[0]) + hex2(a[1]) + hex2(a[2]); }
  function lerp(a, b, t) { return a + (b - a) * t; }

  var WHITE = rgb(255, 255, 255);

  // ---- Base brand data ---------------------------------------------------
  var primary = [
    ["Black",          0,   0,   0,   "#000000"],
    ["White",          255, 255, 255, "#FFFFFF"],
    ["Brand Yellow",   243, 214, 48,  "#F3D630"],
    ["Brand Sky",      63,  169, 245, "#3FA9F5"]
  ];
  var secondary = [
    ["Client Purple",  92,  2,   105, "#5C0269"],
    ["Client Scarlet", 123, 4,   41,  "#7B0429"],
    ["Dev Blue",       0,   123, 196, "#007BC4"],
    ["Dev Teal",       0,   145, 136, "#009188"],
    ["Partner Green",  12,  142, 35,  "#0C8E23"],
    ["Partner Lime",   122, 157, 14,  "#7A9D0E"],
    ["Neutral Indigo", 17,  20,  173, "#1114AD"],
    ["Neutral Gray",   63,  63,  63,  "#3F3F3F"]
  ];

  // ---- Ramp construction ---------------------------------------------------
  // Each ramp row = 7 chips. A chip is either:
  //   { hsb:[h,s,b], name } (computed)  or  { fixed:[r,g,b], name, hex, orig }
  //
  // Yellow & Sky rows: Hannah's draft S/B steps, hue snapped to anchors.
  // Six generated rows: darks at S=100 (B interpolated toward a floor of 8),
  // lights are tints (S tapers, B rises toward 100). Gray: S=0 ladder.

  var BLACK_FLOOR = 8;
  var DARK_F  = [0.22, 0.45, 0.72];       // darkest, darker, darkened (lerp floor->origB)
  var LIGHT_G = [0.45, 0.70, 0.88];       // light, lighter, lightest (lerp orig->white)

  function genRamp(name, r, g, b, hexLabel) {
    var hsb = rgbToHsb(r, g, b);
    var hue = hsb[0], S = hsb[1], B = hsb[2];
    var isGray = S < 1;
    var sat = isGray ? 0 : 100;
    var chips = [
      { hsb: [hue, sat, lerp(BLACK_FLOOR, B, DARK_F[0])], name: "Hue Darkest"  },
      { hsb: [hue, sat, lerp(BLACK_FLOOR, B, DARK_F[1])], name: "Hue Darker"   },
      { hsb: [hue, sat, lerp(BLACK_FLOOR, B, DARK_F[2])], name: "Hue Darkened" },
      { fixed: [r, g, b], name: name, hex: hexLabel, orig: true },
      { hsb: [hue, S * (1 - LIGHT_G[0]), lerp(B, 100, LIGHT_G[0])], name: "Hue Light"    },
      { hsb: [hue, S * (1 - LIGHT_G[1]), lerp(B, 100, LIGHT_G[1])], name: "Hue Lighter"  },
      { hsb: [hue, S * (1 - LIGHT_G[2]), lerp(B, 100, LIGHT_G[2])], name: "Hue Lightest" }
    ];
    if (isGray) {
      for (var k = 0; k < chips.length; k++) {
        if (chips[k].name === "Hue Darkened") chips[k].name = "Hue Dark";
      }
    }
    return { label: name, chips: chips };
  }

  // Yellow row — Hannah's S/B steps, hue locked to 51 deg
  var YH = 51;
  var yellowRamp = { label: "Brand Yellow", chips: [
    { hsb: [YH, 100, 10],  name: "Hue Darkest"   },
    { hsb: [YH, 100, 25],  name: "Hue Darker"    },
    { hsb: [YH, 100, 65],  name: "Hue Darkened"  },
    { hsb: [YH, 100, 95],  name: "Hue Saturated" },
    { fixed: [243, 214, 48], name: "Brand Yellow", hex: "#F3D630", orig: true },
    { hsb: [YH, 50, 100],  name: "Hue Lighter"   },
    { hsb: [YH, 25, 100],  name: "Hue Lightest"  }
  ]};

  // Sky row — Hannah's S/B steps, hue locked to 205 deg; Dev Blue rides along
  var SH = 205;
  var skyRamp = { label: "Brand Sky", chips: [
    { hsb: [SH, 100, 15],  name: "Hue Darkest"  },
    { hsb: [SH, 100, 35],  name: "Hue Darker"   },
    { hsb: [SH, 100, 55],  name: "Hue Darkened" },
    { fixed: [0, 123, 196],  name: "Dev Blue",  hex: "#007BC4", orig: true },
    { fixed: [63, 169, 245], name: "Brand Sky", hex: "#3FA9F5", orig: true },
    { hsb: [SH, 50, 96],   name: "Hue Lighter"  },
    { hsb: [SH, 40, 96],   name: "Hue Lightest" }
  ]};

  var ramps = [
    yellowRamp,
    skyRamp,
    genRamp("Client Purple",  92,  2,   105, "#5C0269"),
    genRamp("Client Scarlet", 123, 4,   41,  "#7B0429"),
    genRamp("Dev Teal",       0,   145, 136, "#009188"),
    genRamp("Partner Green",  12,  142, 35,  "#0C8E23"),
    genRamp("Partner Lime",   122, 157, 14,  "#7A9D0E"),
    genRamp("Neutral Indigo", 17,  20,  173, "#1114AD"),
    genRamp("Neutral Gray",   63,  63,  63,  "#3F3F3F")
  ];

  // Resolve every chip to rgb + hex
  var ri, ci;
  for (ri = 0; ri < ramps.length; ri++) {
    var chs = ramps[ri].chips;
    for (ci = 0; ci < chs.length; ci++) {
      var ch = chs[ci];
      if (ch.fixed) { ch.rgbArr = ch.fixed; ch.hexStr = ch.hex; }
      else { ch.rgbArr = hsbToRgbArr(ch.hsb[0], ch.hsb[1], ch.hsb[2]); ch.hexStr = toHex(ch.rgbArr); }
    }
  }

  // ---- Swatch groups -----------------------------------------------------
  function addGroup(groupName, entries) {
    // entries: [[name, r, g, b], ...]
    var sg = null;
    try { sg = doc.swatchGroups.add(); sg.name = groupName; } catch (e) {}
    for (var i = 0; i < entries.length; i++) {
      try {
        var sw = doc.swatches.add();
        sw.name = entries[i][0];
        sw.color = rgb(entries[i][1], entries[i][2], entries[i][3]);
        if (sg) { try { sg.addSwatch(sw); } catch (e2) {} }
      } catch (e3) {}
    }
  }
  function rows(list) {
    var out = [];
    for (var i = 0; i < list.length; i++) out.push([list[i][0], list[i][1], list[i][2], list[i][3]]);
    return out;
  }
  addGroup("F1R3FLY Primary", rows(primary));
  addGroup("F1R3FLY Secondary", rows(secondary));
  for (ri = 0; ri < ramps.length; ri++) {
    var entries = [];
    for (ci = 0; ci < ramps[ri].chips.length; ci++) {
      var c2 = ramps[ri].chips[ci];
      if (c2.orig) continue; // originals already live in Primary/Secondary groups
      entries.push([ramps[ri].label + " — " + c2.name + " " + c2.hexStr,
                    c2.rgbArr[0], c2.rgbArr[1], c2.rgbArr[2]]);
    }
    addGroup("F1R3FLY " + ramps[ri].label + " Hue Ramp", entries);
  }

  // ---- Gradients ---------------------------------------------------------
  var gradDefs = [
    ["F1R3FLY Primary Gradient (Yellow-Sky)", [243, 214, 48], [63, 169, 245]],
    ["F1R3FLY Client (Purple-Scarlet)", [92, 2, 105],  [123, 4, 41]],
    ["F1R3FLY Developer (Blue-Teal)",   [0, 123, 196], [0, 145, 136]],
    ["F1R3FLY Partner (Green-Lime)",    [12, 142, 35], [122, 157, 14]],
    ["F1R3FLY Neutral (Indigo-Gray)",   [17, 20, 173], [63, 63, 63]]
  ];
  function makeGrad(def) {
    try {
      var g = doc.gradients.add();
      g.name = def[0];
      g.type = GradientType.LINEAR;
      g.gradientStops[0].rampPoint = 0;
      g.gradientStops[0].color = rgb(def[1][0], def[1][1], def[1][2]);
      g.gradientStops[1].rampPoint = 100;
      g.gradientStops[1].color = rgb(def[2][0], def[2][1], def[2][2]);
      return g;
    } catch (e) { return null; }
  }
  var gradObjs = [];
  var i;
  for (i = 0; i < gradDefs.length; i++) gradObjs.push(makeGrad(gradDefs[i]));

  // ---- Sheet -------------------------------------------------------------
  var MARGIN = 30, CHIP_W = 150, CHIP_H = 52, COL_GAP = 40;
  var R_CHIP_W = 94, R_CHIP_H = 46, R_PITCH_X = 110, R_PITCH_Y = 88;

  var plate = doc.pathItems.rectangle(H, 0, W, H);   // full-bleed black
  plate.fillColor = rgb(0, 0, 0);
  plate.stroked = false;

  function label(txt, x, top, size, bold) {
    var t = doc.textFrames.add();
    t.contents = txt;
    t.left = x;
    t.top = top;
    try {
      t.textRange.characterAttributes.size = size;
      t.textRange.characterAttributes.fillColor = WHITE;
      try {
        t.textRange.characterAttributes.textFont =
          app.textFonts.getByName(bold ? "SourceSans3-Bold" : "SourceSans3-Regular");
      } catch (eFont) {
        t.textRange.characterAttributes.textFont =
          app.textFonts.getByName("SourceSans3-Regular");
      }
    } catch (e) { /* font not installed — system default is fine */ }
    return t;
  }

  function bigChip(c, x, top) {
    var r = doc.pathItems.rectangle(top, x, CHIP_W, CHIP_H);
    r.fillColor = rgb(c[1], c[2], c[3]);
    r.stroked = true;
    r.strokeColor = rgb(63, 63, 63);
    r.strokeWidth = 0.5;
    label(c[0] + "  " + c[4], x, top - CHIP_H - 6, 8, false);
  }
  function chipRow(list, startIdx, count, top) {
    for (var k = 0; k < count; k++) {
      var c = list[startIdx + k];
      if (!c) return;
      bigChip(c, MARGIN + k * (CHIP_W + COL_GAP), top);
    }
  }
  function gradBar(gradObj, name, top, w) {
    if (!gradObj) return;
    var bar = doc.pathItems.rectangle(top, MARGIN, w, 26);
    var gc = new GradientColor();
    gc.gradient = gradObj;
    gc.angle = 0;
    bar.fillColor = gc;
    bar.stroked = false;
    label(name, MARGIN + w + 20, top - 6, 8, false);
  }
  function rampRow(ramp, top) {
    for (var k = 0; k < ramp.chips.length; k++) {
      var ch = ramp.chips[k];
      var x = MARGIN + k * R_PITCH_X;
      var r = doc.pathItems.rectangle(top, x, R_CHIP_W, R_CHIP_H);
      r.fillColor = rgb(ch.rgbArr[0], ch.rgbArr[1], ch.rgbArr[2]);
      r.stroked = true;
      r.strokeColor = rgb(63, 63, 63);
      r.strokeWidth = 0.5;
      if (ch.orig) label("ORIGINAL", x, top + 12, 7, true);
      label(ch.name + " " + ch.hexStr, x, top - R_CHIP_H - 5, 7, false);
    }
  }

  // date string
  var months = ["January","February","March","April","May","June",
                "July","August","September","October","November","December"];
  var now = new Date();
  var dateStr = months[now.getMonth()] + " " + now.getDate() + ", " + now.getFullYear();

  function y(offsetFromTop) { return H - offsetFromTop; }

  label("F1R3FLY BRAND COLOR SYSTEM — " + dateStr, MARGIN, y(18), 17, true);

  label("PRIMARY — leads every F1R3FLY representation", MARGIN, y(70), 13, true);
  chipRow(primary, 0, 4, y(105));
  gradBar(gradObjs[0], "F1R3FLY Primary Gradient  (Yellow-Sky)", y(205), 560);

  label("SECONDARY — topic / audience color coding only, never the lead", MARGIN, y(265), 13, true);
  chipRow(secondary, 0, 4, y(300));
  chipRow(secondary, 4, 4, y(398));
  var barTop = y(495);
  for (i = 1; i < gradObjs.length; i++) {
    gradBar(gradObjs[i], gradDefs[i][0], barTop, 420);
    barTop -= 44;
  }

  label("HUE VARIANTS (hue-locked tints + shades)", MARGIN, y(700), 13, true);
  label("Rule: any brand color may be lightened, darkened, or shifted in saturation — the HUE stays constant.", MARGIN, y(726), 9, false);
  label("Hue anchors: Yellow 51°  ·  Sky 205°  ·  secondary colors lock to their own hue.", MARGIN, y(741), 9, false);

  var rampTop = y(790);
  for (ri = 0; ri < ramps.length; ri++) {
    rampRow(ramps[ri], rampTop);
    rampTop -= R_PITCH_Y;
  }

  alert("F1R3FLY color system sheet built (June 12, v4):\n" +
        "9 hue-locked ramp rows (63 chips), all values computed at exact hue.\n" +
        "Swatch groups: Primary, Secondary, 9 ramps, 5 gradients.\n\n" +
        "Compare against your hand-built sheet, then Save As over\n" +
        "f1r3fly-brand-color-system-06.11.2026.ai (or today's date).");
})();
