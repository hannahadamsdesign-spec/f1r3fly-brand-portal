// =====================================================================
// F1R3FLY Brand Swatches + Gradients — Illustrator library builder
// Hannah Adams / F1R3FLY Industries — June 10, 2026 (v3)
//
// v3 rebuilds Hannah's own sheet (02 Working files/
// f1r3fly-brand-color-system.ai, June 10 evening) with exact math:
//   - SAGE IS GONE. Removed from the system entirely. Future assets
//     move toward Blue or Yellow.
//   - PRIMARY row = Black, White, Brand Yellow, Brand Sky
//     (+ the Yellow>Sky gradient). Primary always leads.
//   - SECONDARY = 8 audience colors + 4 audience gradients.
//   - Hue anchors: Yellow 51° · Sky 205° (only two now).
//   - EXAMPLES: hue-locked light/dark pairs per primary hue.
//     Dark values snapped to exact anchors from Hannah's draft:
//       Dark Yellow #332B00 (was #332A00, hue 49.4°>51°)
//       Dark Sky    #003257 (was #003556, hue 203°>205°)
//   - Dev Blue hue-snap (#007BC4 > #0072C4) still PROPOSED, not applied.
//
// HOW TO USE:
//   1. Illustrator > File > Scripts > Other Script... > pick this file
//   2. Builds the color-system sheet + named swatch groups + gradients
//   3. Save as f1r3fly-brand-swatches.ai
//   4. Load anywhere via Swatches panel menu > Open Swatch Library >
//      Other Library... (NOT File > Open)
// =====================================================================

(function () {
  var W = 820, H = 940;
  var doc = app.documents.add(DocumentColorSpace.RGB, W, H);

  function rgb(r, g, b) {
    var c = new RGBColor();
    c.red = r; c.green = g; c.blue = b;
    return c;
  }

  var WHITE = rgb(255, 255, 255);

  // ---- Color data ------------------------------------------------------
  var primary = [
    ["Black",          0,   0,   0,   "#000000"],
    ["White",          255, 255, 255, "#FFFFFF"],
    ["Brand Yellow",   243, 214, 48,  "#F3D630"],
    ["Brand Sky",      63,  169, 245, "#3FA9F5"]
  ];
  var secondary = [
    ["Client Purple",  92,  2,   105, "#5C0269"],
    ["Client Scarlet", 123, 4,   41,  "#7B0429"],
    ["Dev Blue",       0,   123, 196, "#007BC4"],
    ["Dev Teal",       0,   145, 136, "#009188"],
    ["Partner Green",  12,  142, 35,  "#0C8E23"],
    ["Partner Lime",   122, 157, 14,  "#7A9D0E"],
    ["Neutral Indigo", 17,  20,  173, "#1114AD"],
    ["Neutral Gray",   63,  63,  63,  "#3F3F3F"]
  ];
  var examples = [
    ["Light Yellow",   247, 228, 120, "#F7E478"],
    ["Dark Yellow",    51,  43,  0,   "#332B00"],
    ["Light Sky",      130, 199, 248, "#82C7F8"],
    ["Dark Sky",       0,   50,  87,  "#003257"]
  ];

  // ---- Swatch groups -----------------------------------------------------
  var swatchData = [
    ["F1R3FLY Primary", primary],
    ["F1R3FLY Secondary", secondary],
    ["F1R3FLY Hue Variant Examples", examples]
  ];
  var gi, i, sw, sg;
  for (gi = 0; gi < swatchData.length; gi++) {
    sg = null;
    try { sg = doc.swatchGroups.add(); sg.name = swatchData[gi][0]; } catch (e) {}
    var list = swatchData[gi][1];
    for (i = 0; i < list.length; i++) {
      try {
        sw = doc.swatches.add();
        sw.name = list[i][0];
        sw.color = rgb(list[i][1], list[i][2], list[i][3]);
        if (sg) { try { sg.addSwatch(sw); } catch (e2) {} }
      } catch (e) {}
    }
  }

  // ---- Gradients ---------------------------------------------------------
  var primaryGrad =
    ["F1R3FLY Primary Gradient (Yellow-Sky)", [243, 214, 48], [63, 169, 245]];
  var secondaryGrads = [
    ["F1R3FLY Client (Purple-Scarlet)", [92, 2, 105],  [123, 4, 41]],
    ["F1R3FLY Developer (Blue-Teal)",   [0, 123, 196], [0, 145, 136]],
    ["F1R3FLY Partner (Green-Lime)",    [12, 142, 35], [122, 157, 14]],
    ["F1R3FLY Neutral (Indigo-Gray)",   [17, 20, 173], [63, 63, 63]]
  ];
  function makeGrad(def) {
    try {
      var g = doc.gradients.add();
      g.name = def[0];
      g.type = GradientType.LINEAR;
      g.gradientStops[0].rampPoint = 0;
      g.gradientStops[0].color = rgb(def[1][0], def[1][1], def[1][2]);
      g.gradientStops[1].rampPoint = 100;
      g.gradientStops[1].color = rgb(def[2][0], def[2][1], def[2][2]);
      return g;
    } catch (e) { return null; }
  }
  var primaryGradObj = makeGrad(primaryGrad);
  var secondaryGradObjs = [];
  for (i = 0; i < secondaryGrads.length; i++) {
    secondaryGradObjs.push(makeGrad(secondaryGrads[i]));
  }

  // ---- Sheet -------------------------------------------------------------
  // Grid: margin 30, chip 150x52, column gap 40 > columns at 30/220/410/600.
  // Example pairs: light+dark 20pt apart, 60pt between pairs > 30/200/410/580.
  var MARGIN = 30, CHIP_W = 150, CHIP_H = 52, COL_GAP = 40;

  var plate = doc.pathItems.rectangle(H, 0, W, H);   // full-bleed black
  plate.fillColor = rgb(0, 0, 0);
  plate.stroked = false;

  function label(txt, x, top, size, bold) {
    var t = doc.textFrames.add();
    t.contents = txt;
    t.left = x;
    t.top = top;
    try {
      t.textRange.characterAttributes.size = size;
      t.textRange.characterAttributes.fillColor = WHITE;
      try {
        t.textRange.characterAttributes.textFont =
          app.textFonts.getByName(bold ? "SourceSans3-Bold" : "SourceSans3-Regular");
      } catch (eFont) {
        t.textRange.characterAttributes.textFont =
          app.textFonts.getByName("SourceSans3-Regular");
      }
    } catch (e) { /* font not installed — system default is fine */ }
    return t;
  }

  function chip(c, x, top) {
    var r = doc.pathItems.rectangle(top, x, CHIP_W, CHIP_H);
    r.fillColor = rgb(c[1], c[2], c[3]);
    r.stroked = true;
    r.strokeColor = rgb(63, 63, 63);
    r.strokeWidth = 0.5;
    label(c[0] + "  " + c[4], x, top - CHIP_H - 6, 8, false);
  }

  function chipRow(list, startIdx, count, top, xs) {
    for (var k = 0; k < count; k++) {
      var c = list[startIdx + k];
      if (!c) return;
      chip(c, xs ? xs[k] : MARGIN + k * (CHIP_W + COL_GAP), top);
    }
  }

  function gradBar(gradObj, name, top, w) {
    if (!gradObj) return;
    var bar = doc.pathItems.rectangle(top, MARGIN, w, 26);
    var gc = new GradientColor();
    gc.gradient = gradObj;
    gc.angle = 0;
    bar.fillColor = gc;
    bar.stroked = false;
    label(name, MARGIN + w + 20, top - 6, 8, false);
  }

  label("F1R3FLY BRAND COLOR SYSTEM — June 10, 2026", MARGIN, 922, 17, true);

  label("PRIMARY — leads every F1R3FLY representation", MARGIN, 872, 13, true);
  chipRow(primary, 0, 4, 826);
  gradBar(primaryGradObj, "F1R3FLY Primary Gradient  (Yellow-Sky)", 725, 560);

  label("SECONDARY — topic / audience color coding only, never the lead", MARGIN, 657, 13, true);
  chipRow(secondary, 0, 4, 615);
  chipRow(secondary, 4, 4, 517);
  var barY = 419;
  for (i = 0; i < secondaryGradObjs.length; i++) {
    gradBar(secondaryGradObjs[i], secondaryGrads[i][0], barY, 420);
    barY -= 44;
  }

  label("LIGHT VARIANTS (hue-locked tints)", MARGIN, 228, 13, true);
  label("Rule: any brand color may be lightened, darkened, or shifted in saturation — the HUE stays constant.", MARGIN, 196, 9, false);
  label("Hue anchors: Yellow 51°  ·  Sky 205°", MARGIN, 181, 9, false);

  label("EXAMPLES", MARGIN, 135, 13, true);
  chipRow(examples, 0, 4, 100, [30, 200, 410, 580]);

  alert("F1R3FLY color system built (June 10, v3 — sage removed):\n16 solids in 3 swatch groups + 5 gradient swatches.\n\nSave as f1r3fly-brand-swatches.ai, then load anywhere via Swatches panel menu > Open Swatch Library > Other Library…");
})();
